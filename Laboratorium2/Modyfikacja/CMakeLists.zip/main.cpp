#include <iostream>

#include "ComplexNumber.h"
// TIP To <b>Run</b> code, press <shortcut actionId="Run"/> or click the <icon src="AllIcons.Actions.Execute"/> icon in the gutter.
int main() {
    ComplexNumber num1(1,1);
    ComplexNumber num2(1,1);
    ComplexNumber result = num1*num2;

    ComplexNumber a(10, 5);
    ComplexNumber b(4, 3);

    ComplexNumber res = a*b + a/b - a;



    std::cout << result.toString();
}