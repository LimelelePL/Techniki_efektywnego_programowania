
#include "Interface.h"
int main() {

    Interface interface;
    interface.run();

}
